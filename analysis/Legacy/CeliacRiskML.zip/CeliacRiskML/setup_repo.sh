#!/bin/bash
# Professional Git Repository Setup Script
# Run this after cloning the repository

set -e  # Exit on error

echo "==================================================================="
echo "CeliacRiskML Repository Setup"
echo "==================================================================="

# Check Python version
echo ""
echo "[1/5] Checking Python version..."
python_version=$(python --version 2>&1 | awk '{print $2}')
echo "Found Python $python_version"

if ! python -c "import sys; exit(0 if sys.version_info >= (3, 9) else 1)"; then
    echo "ERROR: Python 3.9+ required"
    exit 1
fi

# Install package in development mode
echo ""
echo "[2/5] Installing package in development mode..."
cd analysis/sklearn
pip install -e ".[dev]"
cd ../..

# Install pre-commit hooks
echo ""
echo "[3/5] Installing pre-commit hooks..."
pip install pre-commit
pre-commit install

echo ""
echo "Pre-commit hooks installed. They will run automatically on git commit."

# Create .env from template
echo ""
echo "[4/5] Setting up environment configuration..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env from template. Please edit with your settings:"
    echo "  - HPC credentials"
    echo "  - Data paths"
    echo "  - Resource limits"
else
    echo ".env already exists. Skipping."
fi

# Run tests to verify setup
echo ""
echo "[5/5] Running tests to verify installation..."
cd analysis/sklearn
pytest tests/ -v --tb=short -x

# Summary
echo ""
echo "==================================================================="
echo "Setup Complete!"
echo "==================================================================="
echo ""
echo "Next steps:"
echo "  1. Edit .env with your HPC settings"
echo "  2. Review CONTRIBUTING.md for development workflow"
echo "  3. Run: ced --help"
echo ""
echo "Helpful commands:"
echo "  ced save-splits --help    # Generate train/val/test splits"
echo "  ced train --help          # Train models"
echo "  ced postprocess --help    # Aggregate results"
echo ""
echo "For HPC deployment, see: docs/HPC_MIGRATION_GUIDE.md"
echo "==================================================================="
