# GitHub Repository Setup Guide

This guide walks through setting up the CeliacRiskML repository on GitHub with professional best practices.

## Current Status

You already have a repository at:
- **URL**: `git@github.com:achousal/CeliacRiskML.git`
- **Remote**: `origin`
- **Branch**: `main`

## Step 1: Push New Repository Files

```bash
cd /Users/andreschousal/Projects/Elahi_Lab/CeliacRiskML

# Stage all new repository files
git add .env.example
git add .github/
git add .pre-commit-config.yaml
git add .secrets.baseline
git add CONTRIBUTING.md
git add LICENSE
git add README.md
git add setup_repo.sh
git add GITHUB_SETUP.md

# Create commit
git commit -m "feat: add professional repository structure

- Add .env.example template for configuration
- Add GitHub workflows (tests, lint, security)
- Add PR and issue templates
- Add pre-commit hooks configuration
- Add CONTRIBUTING.md with development guidelines
- Add MIT LICENSE
- Add comprehensive README.md
- Add setup_repo.sh for easy onboarding
- Add .secrets.baseline for secret detection

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>"

# Push to GitHub
git push origin main
```

## Step 2: Configure GitHub Repository Settings

### A. Enable Branch Protection

1. Go to: `https://github.com/achousal/CeliacRiskML/settings/branches`
2. Click "Add branch protection rule"
3. Branch name pattern: `main`
4. Enable:
   - [x] Require a pull request before merging
   - [x] Require approvals (1)
   - [x] Require status checks to pass before merging
     - Add: `test`, `lint`, `secret-scan`
   - [x] Require branches to be up to date before merging
   - [x] Require conversation resolution before merging
   - [x] Do not allow bypassing the above settings

### B. Enable GitHub Actions

1. Go to: `https://github.com/achousal/CeliacRiskML/settings/actions`
2. Workflow permissions:
   - [x] Read and write permissions
   - [x] Allow GitHub Actions to create and approve pull requests

### C. Configure Secrets (if needed)

If you plan to use external services (optional):

1. Go to: `https://github.com/achousal/CeliacRiskML/settings/secrets/actions`
2. Add secrets:
   - `CODECOV_TOKEN` (for coverage reporting)
   - `SLACK_WEBHOOK` (for notifications, optional)

### D. Enable Discussions (optional)

1. Go to: `https://github.com/achousal/CeliacRiskML/settings`
2. Features section
3. Check: [x] Discussions

### E. Add Repository Description

1. Go to: `https://github.com/achousal/CeliacRiskML`
2. Click gear icon next to "About"
3. Add:
   - **Description**: Machine learning pipeline for predicting incident Celiac Disease risk from proteomics
   - **Topics**: `machine-learning`, `bioinformatics`, `proteomics`, `celiac-disease`, `python`, `r`, `sklearn`, `xgboost`
   - **Website**: (leave empty or add lab website)

## Step 3: Set Up Development Workflow

### Create `develop` Branch

```bash
# Create develop branch
git checkout -b develop
git push -u origin develop

# Set develop as default branch for new PRs (do this on GitHub)
# Settings > Branches > Default branch > Switch to develop
```

### Recommended Branch Structure

- `main`: Production-ready code only
- `develop`: Integration branch for features
- `feature/*`: New features
- `fix/*`: Bug fixes
- `refactor/*`: Code improvements

## Step 4: Test GitHub Actions

```bash
# Make a small change to trigger workflows
git checkout -b test/github-actions

# Add a comment to README
echo "" >> README.md
git add README.md
git commit -m "test: trigger GitHub Actions"
git push origin test/github-actions

# Go to GitHub and create a PR to see workflows run
```

## Step 5: Enable Pre-commit Hooks Locally

```bash
# Install pre-commit
pip install pre-commit

# Install hooks
pre-commit install

# Run on all files (initial check)
pre-commit run --all-files

# Now hooks will run automatically on every commit
```

## Step 6: Update Repository Visibility (if needed)

Current repository visibility can be changed at:
`https://github.com/achousal/CeliacRiskML/settings`

Options:
- **Public**: Anyone can see
- **Private**: Only you and collaborators (recommended for research data)

## Step 7: Add Collaborators (if applicable)

1. Go to: `https://github.com/achousal/CeliacRiskML/settings/access`
2. Click "Add people"
3. Enter GitHub username
4. Choose role:
   - **Admin**: Full access
   - **Write**: Can push to branches
   - **Read**: Can view only

## Step 8: Set Up GitHub Pages (optional)

For documentation hosting:

1. Go to: `https://github.com/achousal/CeliacRiskML/settings/pages`
2. Source: Deploy from a branch
3. Branch: `main` / `/docs`
4. Your docs will be at: `https://achousal.github.io/CeliacRiskML`

## Recommended GitHub Integrations

### A. Codecov (Coverage Reporting)

1. Visit: https://codecov.io/
2. Sign in with GitHub
3. Add CeliacRiskML repository
4. Copy token to GitHub secrets as `CODECOV_TOKEN`

### B. Dependabot (Security Updates)

Already enabled by default. Configure at:
`.github/dependabot.yml` (create if needed)

```yaml
version: 2
updates:
  - package-ecosystem: "pip"
    directory: "/analysis"
    schedule:
      interval: "weekly"
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule:
      interval: "weekly"
```

## Testing the Setup

### 1. Clone Fresh Copy

```bash
cd /tmp
git clone git@github.com:achousal/CeliacRiskML.git test-clone
cd test-clone
./setup_repo.sh
```

### 2. Test Workflows

```bash
git checkout -b test/workflows
echo "# Test" >> README.md
git add README.md
git commit -m "test: verify workflows"
git push origin test/workflows
```

Check: `https://github.com/achousal/CeliacRiskML/actions`

### 3. Test Pre-commit

```bash
# Try to commit a .env file (should be blocked)
touch .env
git add .env
git commit -m "test: should fail"  # Should be blocked by pre-commit

# Try to commit code with print() (should be blocked)
echo "print('debug')" >> analysis/src/ced_ml/data/io.py
git add analysis/src/ced_ml/data/io.py
git commit -m "test: should fail"  # Should be blocked
```

## HPC Deployment from GitHub

Once repository is set up, HPC users can:

```bash
# On HPC login node
cd ~/projects
git clone git@github.com:achousal/CeliacRiskML.git
cd CeliacRiskML
./setup_repo.sh

# Or using HTTPS (if SSH not configured)
git clone https://github.com/achousal/CeliacRiskML.git
```

See [docs/HPC_MIGRATION_GUIDE.md](analysis/docs/HPC_MIGRATION_GUIDE.md) for full HPC setup.

## Maintenance

### Regular Tasks

**Weekly:**
- Review open PRs
- Merge approved PRs to `develop`
- Check GitHub Actions status

**Before releases:**
- Merge `develop` → `main`
- Create release tag: `git tag -a v1.0.0 -m "Release 1.0.0"`
- Push tags: `git push origin --tags`

**Monthly:**
- Review and update dependencies
- Check for security alerts
- Update documentation

## Troubleshooting

### Issue: Pre-commit hooks fail

```bash
# Update hooks
pre-commit autoupdate

# Skip hooks temporarily (emergency only)
git commit --no-verify -m "emergency: skip hooks"
```

### Issue: GitHub Actions fail

1. Check workflow logs: `https://github.com/achousal/CeliacRiskML/actions`
2. Common fixes:
   - Update Python version in workflow
   - Install missing dependencies
   - Fix failing tests locally first

### Issue: Can't push to main

Branch protection is working! Create a PR instead:

```bash
git checkout -b fix/my-fix
# make changes
git push origin fix/my-fix
# Create PR on GitHub
```

## Resources

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Pre-commit Framework](https://pre-commit.com/)
- [Conventional Commits](https://www.conventionalcommits.org/)
- [CONTRIBUTING.md](CONTRIBUTING.md) - Project-specific guidelines

## Next Steps

After completing this setup:

1. Review and merge this setup PR
2. Set `develop` as default branch
3. Create first feature branch
4. Test full workflow (feature → PR → merge)
5. Deploy to HPC and validate

Your repository is now production-ready!
