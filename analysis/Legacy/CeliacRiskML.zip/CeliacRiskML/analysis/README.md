# Celiac Disease ML Risk Prediction Pipeline (Incident Risk Score)

## Goals
- Train models to score incident CeD risk (similarity to controls) using pre-diagnosis biomarkers.
- Use incident-only positives in validation and testing for clean prospective evaluation.
- Calibrate risk scores to the test-set prevalence for deployment-aligned probabilities.

## Context
- Labels:
  - Positive: Incident CeD.
  - Negative: Controls.
  - Prevalent CeD is used in TRAIN only (sampled at 50%) to enrich training signal.
- No holdout set in this workflow.
- Splits are three-way: 50% TRAIN / 25% VAL / 25% TEST.
- TRAIN controls are downsampled to a case:control ratio of 1:5 (cases = incident + prevalent in TRAIN).

## Implementation Summary
- Split generation (`save_splits.py`):
  - Uses IncidentPlusPrevalent scenario so prevalent is available for TRAIN.
  - Prevalent is excluded from VAL/TEST when `--prevalent_train_only` is set.
  - TRAIN controls are downsampled with `--train_control_per_case 5` (case:control).
- Training and evaluation (`celiacML_faith.py`):
  - Nested CV on TRAIN only (outer repeats + inner folds for tuning).
  - Thresholds are selected on VAL (`--threshold_source val`).
  - Final model is fit on TRAIN and evaluated on TEST.
  - Prevalence-shift calibration uses test prevalence (`--target_prevalence_source test`).
- Metrics for VAL/TEST saved separately (`core/val_metrics.csv`, `core/test_metrics.csv`).

## Pipeline Diagram

```mermaid
flowchart TB
  A[Full proteomics dataset] --> B[save_splits.py - IncidentPlusPrevalent scenario]
  B -->|prevalent_train_only| C{{TRAIN}}
  B --> D{{VAL}}
  B --> E{{TEST}}

  C --> C1[Incident + 50% prevalent + controls]
  C1 --> C2[Downsample controls to 1:5 case:control]

  C2 --> F[celiacML_faith.py]
  D --> F

  F --> G[Outer CV + inner tuning - TRAIN only]
  G --> H[Select thresholds - VAL]
  H --> I[Final fit on TRAIN]
  I --> J[Test inference]

  J --> K[Raw probabilities]
  J --> L[Prevalence-adjusted probs - target prev: TEST]
  K --> M[preds/test_preds/*.csv]
  L --> M
  H --> N[Thresholded yhat_*]
  N --> M

  D --> O[core/val_metrics.csv]
  J --> P[core/test_metrics.csv]
  M --> Q[postprocess_compare.py + compare_models_faith.R]

  classDef data fill:#f4efe6,stroke:#7a5c3b,stroke-width:1px;
  classDef proc fill:#e8f3f8,stroke:#2a5b84,stroke-width:1px;
  classDef out fill:#eef7ec,stroke:#2f6b2f,stroke-width:1px;
  class A,C,D,E,C1,C2 data;
  class B,F,G,H,I,J proc;
  class K,L,M,N,O,P,Q out;
```

## Key Files
- `save_splits.py`: Split generation + train-only prevalence control.
- `celiacML_faith.py`: Model training, nested CV, calibration, metrics.
- `CeD_optimized.lsf`: HPC job runner with updated defaults.
- `run.sh`: Orchestration for split creation + HPC submissions.
- `postprocess_compare.py`: Aggregation across model runs.

## Recommended Run (HPC)

Generate splits (three-way, incident-only VAL/TEST, prevalent TRAIN only):

```bash
python save_splits.py \
  --infile ../Celiac_dataset_proteomics.csv \
  --outdir splits_incident_valtest \
  --mode development \
  --scenarios IncidentPlusPrevalent \
  --n_splits 10 \
  --val_size 0.25 \
  --test_size 0.25 \
  --prevalent_train_only \
  --prevalent_train_frac 0.5 \
  --train_control_per_case 5
```

Submit model jobs:

```bash
bsub < CeD_optimized.lsf
```

Aggregate results:

```bash
python postprocess_compare.py --results_dir results_holdout --n_boot 500
```

## Notes
- Thresholds are selected on VAL to avoid test leakage.
- TEST is used strictly for final reporting; prevalence adjustment uses TEST prevalence.
- If you need a holdout set, use `save_splits.py --mode holdout` and update `CeD_optimized.lsf` accordingly.

## Outputs (per run)
```
results_holdout/
  IncidentPlusPrevalent__MODEL__.../
    core/val_metrics.csv
    core/test_metrics.csv
    preds/val_preds/
    preds/test_preds/
    diagnostics/
```
