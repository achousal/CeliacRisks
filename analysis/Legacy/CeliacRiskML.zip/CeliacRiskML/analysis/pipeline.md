# Celiac Disease ML Pipeline - High-Level Diagram & Architecture

**Last Updated:** 2026-01-16
**Project:** Celiac Disease Risk Prediction (sklearn)
**Purpose:** Comprehensive reference for understanding the complete ML pipeline

---

## Table of Contents

1. [Complete Pipeline Overview](#complete-pipeline-overview)
2. [Phase 1: Data Preparation](#phase-1-data-preparation)
3. [Phase 2: Model Training (Nested CV with Feature Selection & Hyperparameter Tuning)](#phase-2-model-training)
4. [Phase 3: Postprocessing & Evaluation](#phase-3-postprocessing--evaluation)
5. [Phase 4: Holdout Validation](#phase-4-holdout-validation)
6. [Nested CV Architecture](#nested-cv-architecture)
7. [Feature Selection Pipeline](#feature-selection-pipeline)
8. [Hyperparameter Tuning Grids](#hyperparameter-tuning-grids)
9. [Three-Way Validation Split](#three-way-validation-split)
10. [Data Flow Summary](#data-flow-summary)

---

## Complete Pipeline Overview

```
┌────────────────────────────────────────────────────────────────┐
│ PHASE 1: Data Preparation (save_splits.py)                    │
│ Input: Celiac_dataset_proteomics.csv (43,960 samples)         │
│ Output: Three-way splits (TRAIN/VAL/TEST, 10 random seeds)   │
└────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────┐
│ PHASE 2: Model Training (celiacML_faith.py via CeD_optimized.lsf) │
│ 4 Models in parallel: RF, XGBoost, LinSVM_cal, LR_EN          │
│ - Nested CV on TRAIN (feature selection + hyperparameter tuning) │
│ - Out-of-fold (OOF) predictions                               │
│ - Bootstrap confidence intervals (500 iterations)             │
└────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────┐
│ PHASE 3: Postprocessing (postprocess_compare.py + R scripts)  │
│ - Aggregate metrics across models                             │
│ - Generate ROC, calibration, DCA plots                        │
│ - Cross-model comparison & ranking                            │
└────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────┐
│ PHASE 4: Holdout Validation (eval_holdout.py, ONE-TIME ONLY)  │
│ - Apply best model to holdout set (if created)                │
│ - Final external validation metrics                           │
└────────────────────────────────────────────────────────────────┘
```

---

## Phase 1: Data Preparation

### Input Data
```
Celiac_dataset_proteomics.csv (2.5 GB, 43,960 samples)
├─ Total samples: 43,960
├─ Controls: 43,662
├─ Incident CeD: 148 (BEFORE diagnosis)
├─ Prevalent CeD: 150 (AFTER diagnosis - TRAIN only)
├─ Proteins: 2,920 (_resid columns)
└─ Demographics: age, BMI, sex, ethnicity (17% missing)
```

### Three-Way Split (without CV nesting)
```
Original Data (43,960 samples)
│
├─ TRAIN (50% = 21,980)
│  ├─ 74 incident CeD
│  ├─ 75 prevalent CeD (50% sampling, TRAIN only)
│  └─ 370 controls (1:5 case:control ratio)
│
├─ VAL (25% = 10,990)
│  ├─ 37 incident CeD only
│  └─ 185 controls
│
└─ TEST (25% = 10,990)
   ├─ 37 incident CeD only
   └─ 185 controls
```

### Key Parameters
```
--mode:                   development (or holdout for external validation)
--scenarios:              IncidentPlusPrevalent
--n_splits:               10 (repeated seeds for robust estimates)
--val_size:               0.25 (25%)
--test_size:              0.25 (25%)
--prevalent_train_only:   True (prevent reverse causality)
--prevalent_train_frac:   0.5 (use 50% of prevalent in TRAIN)
--train_control_per_case: 5 (downsample to 1:5 ratio)
```

---

## Phase 2: Model Training

### Overview
```
TRAIN split (21,980 samples)
│
└─ Nested 5-Fold Stratified K-Fold CV with 10 repeats
   = 50 total iterations (5 folds × 10 repeats)

   Each iteration contains:
   ├─ Feature Selection (3-step process)
   ├─ Hyperparameter Tuning (200 random combinations)
   ├─ Model Training (on 80% of fold)
   └─ Out-of-fold Predictions (on 20% of fold)
```

### Complete Nested CV Architecture

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ TRAIN (50% = 21,980 samples)                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │ FEATURE SELECTION STEP 1: Mann-Whitney Screening (Global, one-time)   │  │
│ │ ┌────────────────────────────────────────────────────────────────────┐ │  │
│ │ │ Input: 2,920 proteins                                             │ │  │
│ │ │ Method: Mann-Whitney U test (case vs control effect size)         │ │  │
│ │ │ Output: Top 1,000 proteins (by p-value)                          │ │  │
│ │ └────────────────────────────────────────────────────────────────────┘ │  │
│ └────────────────────────────────────────────────────────────────────────┘  │
│                                    ↓                                         │
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │ OUTER CV: RepeatedStratifiedKFold(n_splits=5, n_repeats=10)           │  │
│ │ = 50 total iterations (5 folds × 10 repeats)                          │  │
│ │                                                                        │  │
│ │ For each of 50 iterations (e.g., Fold 1, Repeat 1):                  │  │
│ │ ┌──────────────────────────────────────────────────────────────────┐  │  │
│ │ │ TRAIN FOLD: 80% (17,584 samples)                                 │  │  │
│ │ │ TEST FOLD:  20% (4,396 samples) → OOF predictions                │  │  │
│ │ │                                                                   │  │  │
│ │ │ ┌────────────────────────────────────────────────────────────┐   │  │  │
│ │ │ │ INNER CV: StratifiedKFold(n_splits=5, shuffle=True)       │   │  │  │
│ │ │ │ = 5 inner folds (for hyperparameter tuning & FS)          │   │  │  │
│ │ │ │                                                            │   │  │  │
│ │ │ │ For each of 5 inner folds:                                │   │  │  │
│ │ │ │ ┌──────────────────────────────────────────────────────┐  │   │  │  │
│ │ │ │ │ Inner TRAIN (80%): 14,067 samples                   │  │   │  │  │
│ │ │ │ │ Inner TEST (20%):   3,517 samples                   │  │   │  │  │
│ │ │ │ │                                                      │  │   │  │  │
│ │ │ │ │ ┌────────────────────────────────────────────────┐   │  │   │  │  │
│ │ │ │ │ │ FEATURE SELECTION STEP 2: K-best Selection   │   │  │   │  │  │
│ │ │ │ │ │ (Per inner fold)                             │   │  │   │  │  │
│ │ │ │ │ │                                              │   │  │   │  │  │
│ │ │ │ │ │ Input: Top 1,000 proteins (from Step 1)     │   │  │   │  │  │
│ │ │ │ │ │ Method: SelectKBest (univariate F-test)     │   │  │   │  │  │
│ │ │ │ │ │ K values tested: 25, 50, 100, 200, 300,    │   │  │   │  │  │
│ │ │ │ │ │                 400, 600, 800              │   │  │   │  │  │
│ │ │ │ │ │                                              │   │  │   │  │  │
│ │ │ │ │ │ (K is tuned via RandomizedSearchCV below)  │   │  │   │  │  │
│ │ │ │ │ └────────────────────────────────────────────┘   │  │   │  │  │
│ │ │ │ │                         ↓                        │  │   │  │  │
│ │ │ │ │ ┌────────────────────────────────────────────────┐   │  │   │  │  │
│ │ │ │ │ │ HYPERPARAMETER TUNING                          │   │  │   │  │  │
│ │ │ │ │ │ RandomizedSearchCV (200 random combinations)   │   │  │   │  │  │
│ │ │ │ │ │                                                │   │  │   │  │  │
│ │ │ │ │ │ Test combinations of:                          │   │  │   │  │  │
│ │ │ │ │ │ ├─ K (feature count): 8 values               │   │  │   │  │  │
│ │ │ │ │ │ └─ Model hyperparameters (depends on model)  │   │  │   │  │  │
│ │ │ │ │ │                                                │   │  │   │  │  │
│ │ │ │ │ │ For each combination:                          │   │  │   │  │  │
│ │ │ │ │ │ ├─ Select K best features                     │   │  │   │  │  │
│ │ │ │ │ │ ├─ Train model on inner TRAIN (14,067)       │   │  │   │  │  │
│ │ │ │ │ │ ├─ Evaluate on inner TEST (3,517)            │   │  │   │  │  │
│ │ │ │ │ │ └─ Compute Brier score                        │   │  │   │  │  │
│ │ │ │ │ │                                                │   │  │   │  │  │
│ │ │ │ │ │ BEST COMBINATION:                              │   │  │   │  │  │
│ │ │ │ │ │ → Best K value (e.g., K=150)                 │   │  │   │  │  │
│ │ │ │ │ │ → Best hyperparameters                        │   │  │   │  │  │
│ │ │ │ │ │ → Highest Brier score                         │   │  │   │  │  │
│ │ │ │ │ └────────────────────────────────────────────────┘   │  │   │  │  │
│ │ │ │ │                         ↓                        │  │   │  │  │
│ │ │ │ │ ┌────────────────────────────────────────────────┐   │  │   │  │  │
│ │ │ │ │ │ Train final model on inner TRAIN with best:  │   │  │   │  │  │
│ │ │ │ │ │ ├─ K=150 features selected                    │   │  │   │  │  │
│ │ │ │ │ │ └─ Best hyperparameters                       │   │  │   │  │  │
│ │ │ │ │ │                                                │   │  │   │  │  │
│ │ │ │ │ │ Predict on inner TEST:                         │   │  │   │  │  │
│ │ │ │ │ │ → Compute inner validation Brier score        │   │  │   │  │  │
│ │ │ │ │ │ → Record selected proteins for Step 3         │   │  │   │  │  │
│ │ │ │ │ └────────────────────────────────────────────────┘   │  │   │  │  │
│ │ │ │ │                                                      │  │   │  │  │
│ │ │ │ │ (Repeat for all 5 inner folds)                      │  │   │  │  │
│ │ │ │ │                                                      │  │   │  │  │
│ │ │ │ │ Select: Best K + hyperparams across inner folds     │  │   │  │  │
│ │ │ │ │         (by average inner CV Brier score)           │  │   │  │  │
│ │ │ │ └──────────────────────────────────────────────────────┘  │   │  │  │
│ │ │ │                         ↓                               │   │  │  │
│ │ │ │ ┌──────────────────────────────────────────────────────┐  │   │  │  │
│ │ │ │ │ Train final model on full outer TRAIN fold (80%)    │  │   │  │  │
│ │ │ │ │ using best K + hyperparameters                      │  │   │  │  │
│ │ │ │ │                                                      │  │   │  │  │
│ │ │ │ │ Predict on outer TEST fold (20%):                   │  │   │  │  │
│ │ │ │ │ → OOF predictions for this fold (4,396 samples)     │  │   │  │  │
│ │ │ │ │ → Record: Which proteins selected in this iteration │  │   │  │  │
│ │ │ │ └──────────────────────────────────────────────────────┘  │   │  │  │
│ │ │ └──────────────────────────────────────────────────────────┘  │   │  │  │
│ │ └──────────────────────────────────────────────────────────────┘  │   │  │
│ │                         ↓ Repeat ↓                               │   │  │
│ │                 (for all 50 iterations)                          │   │  │
│ └──────────────────────────────────────────────────────────────────┘  │  │
│                                                                              │
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │ FEATURE SELECTION STEP 3: Stability Filtering (Global, after CV)      │  │
│ │                                                                        │  │
│ │ Aggregate selections from 50 outer iterations:                        │  │
│ │ ├─ For each protein: Count = # of folds where selected               │  │
│ │ ├─ Compute: selection_frequency = Count / 50                         │  │
│ │ ├─ Keep if: frequency ≥ 0.75 (selected in ≥38/50 folds)             │  │
│ │ └─ Output: Stable core feature set (~50-100 proteins)               │  │
│ │                                                                        │  │
│ │ Result: {TGM2, CXCL9, ITGB7, MUC2, CRP, ..., HPX}                   │  │
│ │         All stable, selected >75% of the time                         │  │
│ └────────────────────────────────────────────────────────────────────────┘  │
│                                    ↓                                         │
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │ Spearman Correlation Pruning (Global, TRAIN-only)                    │  │
│ │                                                                        │  │
│ │ Input: ~50-100 stable proteins from Step 3                           │  │
│ │ Method: |Spearman ρ| on full TRAIN data                             │  │
│ │ Threshold: |ρ| ≥ 0.85 → collapse to connected components           │  │
│ │ Representative: Highest selection_freq, then univariate effect size  │  │
│ │ Output: Final pruned panel (~40-80 unique proteins)                  │  │
│ └────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────────┐
│ Models Trained (4 parallel jobs): RF, XGBoost, LinSVM_cal, LR_EN            │
├──────────────────────────────────────────────────────────────────────────────┤
│ Each uses final pruned feature panel (~40-80 proteins)                       │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Model Configuration
```
4 Models (trained in parallel):
├─ Random Forest (RF)
├─ XGBoost
├─ Linear SVM with Sigmoid Calibration (LinSVM_cal)
└─ Logistic Regression with ElasticNet (LR_EN)

Scoring metric:
├─ Primary: neg_brier_score (optimize calibration)
├─ Secondary: AUROC, PR-AUC (discrimination)
└─ Calibration: Sigmoid (SVM), Logistic (RF/XGB/LR)
```

---

## Feature Selection Pipeline

### Step 1: Mann-Whitney Screening (Global)
```
Input:  2,920 proteins on full TRAIN
Method: Mann-Whitney U test (case vs control)
        → Rank by p-value / effect size
Output: Top 1,000 proteins
When:   ONCE before CV loop starts
```

### Step 2: K-best Selection (Per Fold, Inside Inner CV)
```
Input:  Top 1,000 proteins (from Step 1)
Method: SelectKBest (univariate F-test)
        K ∈ {25, 50, 100, 200, 300, 400, 600, 800}
When:   Inside Inner CV (5 inner folds × 50 outer iterations = 250 times)
Output: Which K features per fold?
        (K is tuned via RandomizedSearchCV)
```

### Step 3: Stability Filtering (Global, After CV)
```
Input:  All 50 protein selections from Step 2
Method: selection_frequency = # folds selected / 50
        Keep if: frequency ≥ 0.75 (≥38/50 folds)
When:   ONCE after all CV iterations
Output: Stable core set (~50-100 proteins)
```

### Step 4: Spearman Correlation Pruning (Global, After CV)
```
Input:  Stable core proteins from Step 3
Method: Compute pairwise Spearman |ρ| on full TRAIN
        Threshold: |ρ| ≥ 0.85 → connected components
        Representative: Highest selection_freq (tie-break: univariate effect size)
When:   ONCE after all CV iterations
Output: Final pruned panel (~40-80 unique proteins)
```

### Summary
| Step | When | Iterations | Input | Output |
|------|------|-----------|-------|--------|
| 1: Mann-Whitney | Before CV | 1 | 2,920 | 1,000 |
| 2: K-best | Inner CV | 250 | 1,000 | Variable K |
| 3: Stability | After CV | 1 | 50 selections | ~70 proteins |
| 4: Spearman | After CV | 1 | ~70 | ~60 unique |

---

## Hyperparameter Tuning Grids

### Logistic Regression (LR_EN)
```
K (feature count):        8 values (25, 50, 100, 200, 300, 400, 600, 800)
C (regularization):       20 points (1e-4 to 10)
L1_ratio (ElasticNet):    8 values (0.01, 0.05, 0.10, 0.20, 0.25, 0.40, 0.50, 0.60)
class_weight:             balanced

Total combinations: 8 × 20 × 8 × 1 = 1,280
RandomizedSearchCV samples: 200 random combinations
```

### Linear SVM (LinSVM_cal)
```
K (feature count):        8 values (25, 50, 100, 200, 300, 400, 600, 800)
C (regularization):       10 points (1e-4 to 1e4)
class_weight:             balanced
calibration_method:       sigmoid (5-fold CV)

Total combinations: 8 × 10 = 80
RandomizedSearchCV samples: 200 iterations (exhausts all + repeats)
```

### Random Forest (RF)
```
K (feature count):        8 values (25, 50, 100, 200, 300, 400, 600, 800)
n_estimators:             2 values (100, 200)
max_depth:                3 values (8, 10, 12)
min_samples_leaf:         2 values (2, 4)
max_features:             2 values (0.2, 0.3)
class_weight:             2 options (balanced, balanced_subsample)

Total combinations: 8 × 2 × 3 × 2 × 2 × 2 = 384
RandomizedSearchCV samples: 200 combinations
```

### XGBoost
```
K (feature count):        8 values (25, 50, 100, 200, 300, 400, 600, 800)
n_estimators:             2 values (500, 1000)
max_depth:                2 values (3, 7)
learning_rate:            2 values (0.01, 0.1)
subsample:                2 values (0.7, 1.0)
colsample_bytree:         2 values (0.7, 1.0)
scale_pos_weight:         auto (computed from class ratio)

Total combinations: 8 × 2 × 2 × 2 × 2 × 2 = 256
RandomizedSearchCV samples: 200 combinations
```

### Selection Criteria
```
Best Hyperparameters = argmax(mean_brier_score across 5 inner CV folds)

Selected best combination is then used to:
  1. Train on full 80% of outer fold
  2. Predict on 20% OOF test fold
  3. Record: Which proteins were selected
```

---

## Three-Way Validation Split

### Terminology (Important!)
Three different "tests" in your pipeline:

| Term | What It Is | Purpose | Size | When |
|------|-----------|---------|------|------|
| **Fold test (OOF)** | 20% of TRAIN per CV iteration | Nested CV validation | ~4,396 per fold | During training |
| **VAL split** | 25% of original data (separate) | Threshold selection | ~10,990 | After training |
| **TEST split** | 25% of original data (separate) | Final reporting | ~10,990 | After training |

### Visual Hierarchy
```
Original Data (43,960 samples)
│
├─ TRAIN (50% = 21,980 samples)
│  │
│  └─ 5-Fold Stratified K-Fold (NESTED CV)
│     │
│     ├─ Fold 1 iteration: [80% train=17,584 | 20% OOF test=4,396]
│     ├─ Fold 2 iteration: [80% train=17,584 | 20% OOF test=4,396]
│     ├─ Fold 3 iteration: [80% train=17,584 | 20% OOF test=4,396]
│     ├─ Fold 4 iteration: [80% train=17,584 | 20% OOF test=4,396]
│     └─ Fold 5 iteration: [80% train=17,584 | 20% OOF test=4,396]
│        ↓ OOF predictions collected
│        All 21,980 TRAIN samples get out-of-fold predictions
│
├─ VAL (25% = 10,990 samples) ← SEPARATE from TRAIN
│  └─ Used for: Threshold selection @ 95% specificity
│
└─ TEST (25% = 10,990 samples) ← SEPARATE from TRAIN
   └─ Used for: Final metrics reporting
```

### Why 80/20 in K-Fold?
With K=5 folds:
- Each fold has: (K-1)/K = 4/5 = **80% training**, 1/5 = **20% validation**
- Standard tradeoff between training data size and validation reliability
- 20% is large enough for stable performance estimates
- 80% is enough for stable hyperparameter tuning

---

## Phase 3: Postprocessing & Evaluation

### On TRAIN (from OOF predictions)
```
├─ Calibration curve (10 bins)
├─ Learning curves (3-fold, 30%–100% training data)
├─ Feature importance (permutation)
├─ Stable feature panel (panel sizes: 10, 25, 50, 100, 200, 400, 800)
└─ Correlation pruning (threshold: 0.85 Spearman)
```

### On VAL (incident-only)
```
├─ Threshold Selection
│  ├─ Objective: Fixed specificity = 95%
│  └─ Brier score computed
│
├─ Metrics
│  ├─ AUROC, PR-AUC
│  ├─ Sensitivity @ 95%/99%/99.5% specificity
│  ├─ Calibration curve
│  └─ Decision Curve Analysis (DCA) sweep: 0.05%–100%
```

### On TEST (incident-only, gold standard)
```
├─ Final metrics (what gets reported in papers)
├─ Prevalence-adjusted calibration (using TEST prevalence = 0.34%)
├─ Bootstrap CIs (500 iterations)
├─ Sensitivity @ specificity targets (95%, 99%, 99.5%)
└─ DCA net benefit calculations
```

### Cross-Model Comparison
```
postprocess_compare.py:
├─ Aggregate metrics across 4 models + 10 splits
├─ Rank models by Brier score (primary), then AUROC
├─ Generate combined metrics table
└─ Export data for R visualization

compare_models_faith.R:
├─ ROC curves (all 4 models)
├─ Calibration plots (all 4 models)
├─ DCA curves (all 4 models)
├─ Top feature importance comparison
└─ Summary statistics
```

---

## Phase 4: Holdout Validation

**Only run ONCE on completely separate holdout set (30% if created)**

```
eval_holdout.py:
├─ Apply best-performing model to holdout set
├─ Report final external validation metrics
├─ These are the results used in publications
└─ No parameter tuning (parameters locked from TRAIN/VAL/TEST)
```

---

## Nested CV Architecture Summary

### Computation Flow
```
Total nested CV iterations: 50 (outer) × 5 (inner) = 250 model trainings
Total hyperparameter tests: 50 × 5 × 200 = 50,000 configurations evaluated
Total feature selections: 50 (one per outer fold) + stability filtering

Timeline:
├─ Step 1 (Mann-Whitney):   1 run
├─ Inner CV loop:           50 × 5 × 200 = 50,000 configurations
├─ Outer CV loop:           50 model trainings
├─ Step 3 (Stability):      1 run (aggregates all 50)
└─ Step 4 (Spearman):       1 run (on stable core)
```

### Key Properties
```
✓ No data leakage:
  - Features selected on 80%, evaluated on 20%
  - Hyperparameters tuned on inner CV, evaluated on outer CV
  - VAL split never used during training
  - TEST split never used until final reporting

✓ Robust feature selection:
  - Features selected in ≥75% of folds survive
  - Unstable/noisy features filtered out
  - Only truly predictive proteins in final model

✓ Unbiased performance estimates:
  - OOF predictions never seen by trained model
  - Bootstrap CIs provide confidence intervals
  - Nested CV prevents overfitting
```

---

## Data Flow Summary

### Volume at Each Stage
```
Original: 43,960 samples (2,920 proteins)
    ↓
TRAIN (50%): 21,980 samples
├─ Outer CV: 50 iterations
│  └─ Inner CV: 5 folds per iteration
│     └─ 200 hyperparameter configurations per fold
├─ Feature Selection: 2,920 → 1,000 → variable K → 70 → 60 proteins
└─ Models: RF, XGBoost, LinSVM_cal, LR_EN
    ↓
VAL (25%): 10,990 samples
├─ Threshold selection (95% specificity)
└─ Metrics: AUROC, PR-AUC, calibration
    ↓
TEST (25%): 10,990 samples
├─ Apply VAL threshold + VAL calibration
└─ Final metrics (reported in papers)
    ↓
HOLDOUT (30%, if created): ~13,188 samples
└─ External validation (ONE-TIME ONLY)
```

### What Gets Saved
```
results_holdout/
├── IncidentPlusPrevalent__RF__5x10__val0.25__test0.25__hybrid/
│   ├── core/
│   │   ├── val_metrics.csv          ← VAL performance
│   │   ├── test_metrics.csv         ← FINAL REPORTED METRICS
│   │   └── final_model.joblib       ← Trained model
│   ├── preds/
│   │   ├── val_preds/               ← VAL predictions per fold
│   │   └── test_preds/              ← TEST predictions per fold
│   ├── reports/stable_panel/        ← Feature stability
│   └── diagnostics/
│       ├── calibration/             ← Calibration curves
│       ├── learning_curve/          ← Learning curves
│       ├── dca/                     ← Decision curve analysis
│       └── feature_importance/      ← Permutation importance
├── (repeat for XGBoost, LinSVM_cal, LR_EN)
├── COMBINED/                        ← Cross-model metrics
└── HOLDOUT_FINAL/                   ← External validation (if created)
```

---

## Key Configuration Parameters

| Parameter | Value | Purpose |
|-----------|-------|---------|
| `FOLDS` | 5 | Outer CV folds (5-fold = 80% train, 20% test per fold) |
| `REPEATS` | 10 | Repeated stratified K-fold (10 different random seeds) |
| `INNER_FOLDS` | 5 | Inner CV folds for hyperparameter tuning |
| `N_ITER` | 200 | RandomizedSearchCV iterations |
| `SCORING` | neg_brier_score | Optimize calibration (not just AUROC) |
| `SCREEN_TOP_N` | 1,000 | Mann-Whitney pre-filter proteins |
| `STABILITY_THRESH` | 0.75 | Keep proteins in ≥75% of CV folds |
| `KBEST_MAX` | 800 | Max K in K-best grid |
| `PANEL_CORR_THRESH` | 0.85 | Spearman correlation pruning threshold |
| `THRESHOLD_OBJECTIVE` | fixed_spec | Select threshold at 95% specificity |
| `THRESHOLD_SOURCE` | val | Select threshold on VAL (prevent test leakage) |
| `TARGET_PREVALENCE_SOURCE` | test | Calibrate using TEST prevalence (0.34%) |
| `N_BOOT` | 500 | Bootstrap iterations for confidence intervals |

---

## Running the Pipeline

```bash
# 1. Generate splits
python save_splits.py \
  --infile ../../Celiac_dataset_proteomics.csv \
  --outdir splits_test_holdout \
  --mode development \
  --scenarios IncidentPlusPrevalent \
  --n_splits 10 \
  --val_size 0.25 \
  --test_size 0.25 \
  --prevalent_train_only \
  --prevalent_train_frac 0.5 \
  --train_control_per_case 5

# 2. Submit model training (HPC)
bsub < CeD_optimized.lsf

# or use orchestration:
./run.sh

# 3. Postprocess results
python postprocess_compare.py --results_dir results_holdout --n_boot 500

# 4. Visualizations
Rscript compare_models_faith.R --results_root results_holdout

# 5. Holdout evaluation (ONCE ONLY, if holdout set exists)
python eval_holdout.py \
  --infile ../../Celiac_dataset_proteomics.csv \
  --holdout_idx splits_test_holdout/IncidentPlusPrevalent_HOLDOUT_idx.csv \
  --model_artifact results_holdout/IncidentPlusPrevalent__LR_EN__5x10__val0.25__test0.25__hybrid/core/final_model.joblib \
  --outdir results_holdout/HOLDOUT_FINAL \
  --compute_dca
```

---

## Evaluation Metrics

### Primary (Model Selection)
- **Brier Score**: Calibration quality (lower = better)
  - Formula: mean((predicted_prob - true_label)²)

### Discrimination
- **AUROC**: Ranking ability (AUC of ROC curve)
- **PR-AUC**: Precision-recall AUC (for imbalanced data)

### Calibration Quality
- **Calibration slope**: Should be ~1.0
- **Calibration intercept**: Should be ~0.0
- **Calibration bins**: 10 bins for smooth curve visualization

### Clinical Utility
- **Sensitivity @ fixed specificity**: 95%, 99%, 99.5%
- **DCA net benefit**: Clinical utility at decision thresholds
- **Positive predictive value (PPV)**: Precision of risk predictions

---

## Biological Validation

Top proteins typically include established CeD biomarkers:

| Protein | Cohen's d | Clinical Relevance |
|---------|-----------|-------------------|
| **TGM2** | ~1.73 | Primary CeD autoantigen (gold standard) |
| **CXCL9** | ~1.53 | Inflammatory chemokine |
| **ITGB7** | ~1.50 | Gut-homing integrin |
| **MUC2** | ~0.96 | Intestinal mucin |

**Conclusion**: Models capture genuine biological signal, not overfitting.

---

## Important Notes

### Prevalent Case Handling
- Prevalent cases have biomarkers measured **AFTER** diagnosis
- Including in VAL/TEST would introduce **reverse causality bias**
- Current approach: Use for **training signal enrichment only** (50% in TRAIN)
- VAL/TEST remain **prospective** (incident-only) for clean evaluation

### Three-Way Split Design
- **TRAIN (50%)**: Model learning + hyperparameter tuning
- **VAL (25%)**: Threshold selection & bias-aware evaluation
- **TEST (25%)**: Final metrics reporting & external validation proxy

### No Holdout Mode (Development)
- Current workflow uses three-way split (50/25/25)
- To create holdout: `--mode holdout` in save_splits.py
- Holdout should be used **ONCE** for final external validation only

### Calibration & Thresholding
- Thresholds selected on **VAL** to prevent test leakage
- **TEST** strictly for final reporting
- Prevalence adjustment uses **TEST prevalence** for deployment realism

---

**End of Pipeline Documentation**
