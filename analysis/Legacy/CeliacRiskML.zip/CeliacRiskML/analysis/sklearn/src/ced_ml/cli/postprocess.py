"""CLI stub for postprocess command."""

def run_postprocess(**kwargs):
    """Placeholder for postprocess command."""
    print("Postprocessing not yet implemented. Use legacy postprocess_compare.py")
