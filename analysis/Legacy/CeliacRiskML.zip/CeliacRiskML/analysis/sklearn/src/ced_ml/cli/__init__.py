"""CLI subcommands."""

from ced_ml.cli.main import cli, main

__all__ = ["cli", "main"]
