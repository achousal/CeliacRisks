# Celiac Risk ML - Configuration Guide

This guide documents all configurable parameters in the pipeline's orchestration scripts.

## Quick Reference: Most Important Knobs

| Parameter | Location | Purpose | Default | Common Adjustments |
|-----------|----------|---------|---------|-------------------|
| `RUN_MODELS` | run.sh | Which models to train | `LR` | `RF,XGB,SVM,LR` (all) or `RF,LR` (subset) |
| `N_SPLITS` | run.sh | Number of repeated splits | `10` | `1` (quick test), `10` (production) |
| `MODE` | run.sh | Split strategy | `development` | `holdout` (final external validation only) |
| `SCORING` | CeD_optimized.lsf | Metric for hyperparameter tuning | `roc_auc` | `neg_brier_score` (calibration focus) |
| `FOLDS` × `REPEATS` | CeD_optimized.lsf | Outer CV for OOF estimates | `2 × 3` | `5 × 10` (production) |
| `INNER_FOLDS` | CeD_optimized.lsf | Inner CV for hyperparameter tuning | `2` | `5` (production) |
| `N_ITER` | CeD_optimized.lsf | Hyperparameter search breadth | `3` | `200` (production) |
| `SCREEN_TOP_N` | CeD_optimized.lsf | Pre-screening feature count | `1000` | `500-1000` (varies by need) |
| `FEATURE_SELECT` | CeD_optimized.lsf | Dimensionality reduction strategy | `hybrid` | Keep as is (best practice) |

---

## run.sh: Pipeline Orchestration

### Environment Variables

```bash
# MODEL SELECTION
RUN_MODELS="RF,LR"              # Comma/space-separated: RF, XGBoost (XGB), LinSVM_cal (SVM), LR_EN (LR)
                                # Example: RUN_MODELS="RF XGBoost SVM LR" (all 4 models in parallel)

# SPLIT CONFIGURATION
MODE=development                # "development" (3-way split) or "holdout" (3-way + external holdout)
N_SPLITS=10                     # 1 (single split, fast) or 10 (repeated splits, robust)
SEED_START=0                    # Starting seed (e.g., SEED_START=0 with N_SPLITS=10 → seeds 0-9)
TEST_SIZE=0.25                  # Fraction of working set for TEST (25%)
VAL_SIZE=0.25                   # Fraction of working set for VAL (25%)
HOLDOUT_SIZE=0.30              # Fraction of full data for external holdout (if MODE=holdout)
EVAL_CONTROL_PER_CASE=5        # Downsample controls in VAL/TEST: keep 5 per incident case

# RESOURCE CONFIGURATION (per model)
RF_CPUS=8                       # CPU cores for RF (high memory needed)
RF_MEM=8000                     # Memory per CPU in MB (8000 × 8 = 64GB total)
RF_WALLTIME="144:00"            # Walltime limit (6 days)
XGB_CPUS=8; XGB_MEM=4000        # XGBoost resources
SVM_CPUS=8; SVM_MEM=2000        # SVM resources
LR_CPUS=8; LR_MEM=2000          # LR resources

# POSTPROCESSING CONTROL
SKIP_MULTIPLE_POSTPROCESS=1     # 1=skip postprocess_compare.py and compare_models_faith.R
COMPARE_MODEL_SPLITS=1          # 1=aggregate results across repeated splits per model
POSTPROCESS_NOW=0               # 1=run postprocessing immediately on completed jobs

# DCA PARAMETERS
DCA_THRESHOLD_MIN=0.0005        # Min threshold for DCA curve (0.05%)
DCA_THRESHOLD_MAX=1.0           # Max threshold for DCA curve (100%)
DCA_THRESHOLD_STEP=0.001        # Step size for sweep (0.1%)
DCA_MAX_PT=1.0                  # Max threshold for visualization (20%)
DCA_STEP=0.005                  # Step size for visualization (0.5%)
```

### Dry-Run Mode
```bash
DRY_RUN=1 ./run.sh              # Print all commands without executing
```

---

## CeD_optimized.lsf: Model Training Configuration

### CORE CROSS-VALIDATION

```bash
FOLDS=5                         # Outer CV folds per repeat (default 5, reduced to 2 for speed testing)
REPEATS=10                      # Repeats of outer CV (default 10, reduced to 3 for speed testing)
                                # Total: 5×10 = 50 OOF predictions per sample (production)

TEST_SIZE=0.25                  # Fraction for TEST set
VAL_SIZE=0.25                   # Fraction for VAL set

TEMPORAL_SPLIT=0                # 1=split by date column (temporal validation), 0=random split

SPLIT_SEED_START=0              # First seed for repeated splits
SPLIT_SEED_END=9                # Last seed (produces seeds 0-9 = 10 splits)
```

### HYPERPARAMETER TUNING (Inner CV)

```bash
SCORING="roc_auc"               # Inner CV metric: "roc_auc" (discrimination)
                                # "average_precision" (imbalanced), "neg_brier_score" (calibration)
                                # Production: Change to "neg_brier_score" for calibration focus

INNER_FOLDS=5                   # Folds for inner CV hyperparameter tuning (default 5, reduced to 2 for speed)
N_ITER=200                      # RandomizedSearchCV iterations (default 200, reduced to 3 for speed)
GRID_RANDOMIZE=1                # 1=RandomizedSearchCV (sample grid), 0=GridSearchCV (exhaustive)
```

### FEATURE SELECTION

```bash
FEATURE_SELECT="hybrid"         # "none", "kbest", "l1_stability", or "hybrid" (recommended)
SCREEN_METHOD="mannwhitney"     # Pre-screening test: "mannwhitney" or "f_classif"
SCREEN_TOP_N=1000              # Pre-screen to top 1000 proteins (0=keep all 2920)
SCREEN_MIN_N_PER_GROUP=20      # Minimum samples per class for feature inclusion

KBEST_SCOPE="protein"           # Select from: "protein" or "transformed"
KBEST_MAX=800                   # Maximum K value to test
K_GRID="25,50,100,200,300,400,600,800"  # K values for inner CV grid search

STABILITY_THRESH=0.75           # Minimum frequency of selection across folds (0.75 = ≥75% folds)
STABLE_CORR_THRESH=0.85        # Correlation threshold for removing redundant features
```

### MODEL-SPECIFIC PARAMETERS

#### Logistic Regression (LR_EN)
```bash
LR_MAX_ITER=20000               # Convergence iterations
LR_C_MIN=1e-4                   # Min regularization strength (strong)
LR_C_MAX=1e1                    # Max regularization strength (weak)
LR_C_POINTS=20                  # Number of C values to test (log-spaced)
LR_L1_RATIO_GRID="0.01,0.05,0.10,0.20,0.25,0.40,0.50,0.60"  # L1 ratio (0=Ridge, 1=Lasso)
LR_CLASS_WEIGHT_OPTIONS="balanced"  # "balanced" (adjust for class imbalance) or "none"
```

#### Linear SVM (LinSVM_cal)
```bash
SVM_MAX_ITER=15000              # Convergence iterations
SVM_C_MIN=1e-4; SVM_C_MAX=1e4   # C range (1e-4 to 10000)
SVM_C_POINTS=10                 # Number of C values to test
SVM_CLASS_WEIGHT_OPTIONS="balanced"  # Handle class imbalance
CALIBRATION_METHOD="sigmoid"    # "sigmoid" (Platt, default) or "isotonic"
CALIBRATION_CV=5                # CV folds for calibration curve fitting
```

#### Random Forest (RF)
```bash
RF_MAX_DEPTH_GRID="8,10,12,14" # Tree depth (deeper = more expressive but overfit risk)
RF_MIN_SAMPLES_LEAF_GRID="2,4,6"  # Minimum samples per leaf
RF_N_ESTIMATORS_GRID="100,200,400"  # Number of trees
RF_MAX_FEATURES_GRID="0.2,0.3"  # Fraction of features per split
RF_CLASS_WEIGHT_OPTIONS="balanced,balanced_subsample"  # Class weight strategy
RF_BOOTSTRAP=1                  # 1=use bootstrap samples, 0=use full dataset
RF_MAX_SAMPLES=0.8              # Fraction of samples per bootstrap
```

#### XGBoost
```bash
XGB_N_ESTIMATORS_GRID="500,1000"      # Number of boosting rounds
XGB_MAX_DEPTH_GRID="3,7"               # Tree depth (shallow for high-dim data)
XGB_LEARNING_RATE_GRID="0.01,0.1"     # Learning rate (shrinkage)
XGB_SUBSAMPLE_GRID="0.7,1.0"           # Row sub-sampling fraction
XGB_COLSAMPLE_BYTREE_GRID="0.7,1.0"    # Column sub-sampling fraction
XGB_SCALE_POS_WEIGHT="auto"            # Weight for positive class (auto = n_neg/n_pos ≈ 295)
XGB_REG_ALPHA=0.0                      # L1 regularization
XGB_REG_LAMBDA=1.0                     # L2 regularization
XGB_TREE_METHOD="hist"                 # "hist" (histogram, CPU-optimized) or "exact"
```

### EVALUATION METRICS

```bash
TEST_CI=1                       # 1=compute bootstrap CIs on TEST set, 0=skip
N_BOOT=500                      # Bootstrap iterations (higher = more robust but slower)
WRITE_TEST_CI_FILES=1           # 1=save individual bootstrap samples, 0=summary only

LEARNING_CURVE=1                # 1=generate learning curves, 0=skip
LC_CV=3                         # CV folds for learning curve
LC_MIN_FRAC=0.30                # Minimum training fraction (30%)
LC_POINTS=6                     # Number of points along training size axis

FEATURE_REPORTS="all"           # "none", "best" (best model), or "all" (all folds)
FEATURE_REPORT_MAX=200          # Max features to report in importance tables
```

### CLINICAL UTILITY THRESHOLDING

```bash
CONTROL_SPEC_TARGETS="0.95,0.995,0.99"  # Report sensitivity at these specificities
TOPRISK_FRACS="0.01,0.05"               # Report performance for top 1% and 5% risk
RISK_PLOT_SPEC=0.95                     # Target specificity for risk plots
ALPHA_SPECIFICITY=0.90                  # Target specificity for alpha threshold

# Decision Curve Analysis (DCA) - moved to post-processing by default
COMPUTE_DCA=1                           # 1=compute DCA during training, 0=skip (use postprocess)

# CALIBRATION & THRESHOLDING
CALIBRATE_FINAL_MODELS=1                # 1=fit calibration curve on VAL, apply to TEST
THRESHOLD_OBJECTIVE="fixed_spec"        # "max_f1", "max_fbeta", "youden", "fixed_spec", "fixed_ppv"
FIXED_SPEC=0.95                         # Target specificity (if THRESHOLD_OBJECTIVE=fixed_spec)
FIXED_PPV=0.10                          # Target precision (if THRESHOLD_OBJECTIVE=fixed_ppv)
THRESHOLD_SOURCE="val"                  # Select threshold on: "val" (default) or "test"
TARGET_PREVALENCE_SOURCE="test"         # Calibrate to: "test" (deployment scenario) or "val"
```

---

## Common Workflows

### Quick Testing (all 4 models, single split, minimal CV)
```bash
N_SPLITS=1 FOLDS=2 REPEATS=3 N_ITER=3 INNER_FOLDS=2 ./run.sh
```

### Production Run (single seed, robust CV, all models)
```bash
N_SPLITS=1 FOLDS=5 REPEATS=10 N_ITER=200 INNER_FOLDS=5 RUN_MODELS="RF,XGB,SVM,LR" SCORING="neg_brier_score" ./run.sh
```

### Repeated Splits (10 seeds for confidence intervals)
```bash
N_SPLITS=10 FOLDS=5 REPEATS=10 N_ITER=200 INNER_FOLDS=5 ./run.sh
```

### Single Model Debugging (LR only, minimal resources)
```bash
RUN_MODELS="LR" N_SPLITS=1 FOLDS=2 REPEATS=3 N_ITER=3 INNER_FOLDS=2 ./run.sh
```

### Final External Validation (holdout set)
```bash
MODE=holdout N_SPLITS=1 RUN_MODELS="RF,XGB,SVM,LR" ./run.sh
```

### Sensitivity Analysis (test multiple feature screens)
```bash
SENSITIVITY_MODE=1 bsub -J "CeD_sens[1-20]" < CeD_optimized.lsf
python postprocess_compare.py --results_dir results_sensitivity --mode sensitivity
```

---

## Key Design Decisions

1. **Prevalent in TRAIN only**: Enriches signal without reverse causality bias (VAL/TEST incident-only)
2. **Three-way split**: TRAIN (50%), VAL (25% for threshold tuning), TEST (25% for final reporting)
3. **Calibration focus**: Primary metric is `neg_brier_score` not AUROC (ensures reliable risk scores)
4. **Control downsampling**: 1:5 ratio reduces computational burden while preserving discrimination
5. **Hybrid feature selection**: Mann-Whitney screen + K-best + stability (robust to high-dimensionality)

---

## Monitor Job Status

```bash
# Watch all model jobs
bjobs -w | egrep "CeD_RF|CeD_XGB|CeD_SVM|CeD_LR"

# Watch postprocessing pipeline
bjobs -w | egrep "postproc|viz|dashboard"

# Tail live logs
tail -f logs_LR_1.17.26_a/*.out
```
