#!/usr/bin/env python3
"""
Comprehensive test suite for shared_utils.py functionality.

Covers all utility functions added in Phases 1-3 of the refactoring:
- Phase 1: Metrics & utilities (120+ lines)
- Phase 2: Threshold selection & calibration (550+ lines)
- Phase 3: Clinical plotting functions (1,094+ lines)

Test Coverage Goals:
- Metrics: 95% (edge cases for empty arrays, single class, etc.)
- Thresholds: 90% (all 9 functions, tie-breaking scenarios)
- Calibration: 90% (round-trip validation, class preservation)
- Plotting: 80% (plot generation, file writes, metadata)
"""

import numpy as np
import tempfile
import os
import pytest
from pathlib import Path

# ============================================================================
# IMPORTS & FIXTURES
# ============================================================================

from shared_utils import (
    # Section 1: File utilities
    _mkdir,

    # Section 2: Metrics
    _safe_metric,
    prob_metrics,
    format_ci,
    auroc,
    prauc,
    brier,
    logloss,
    compute_metrics_with_cis,
    stratified_bootstrap_ci,
    stratified_bootstrap_diff_ci,

    # Section 3: Thresholds
    threshold_max_f1,
    threshold_max_fbeta,
    threshold_youden,
    threshold_for_specificity,
    threshold_for_precision,
    threshold_from_controls,
    binary_metrics_at_threshold,
    top_risk_capture,
    choose_threshold_objective,

    # Section 4: Calibration
    adjust_probabilities_for_prevalence,
    PrevalenceAdjustedModel,
    calibration_intercept_slope,
    calib_intercept_metric,
    calib_slope_metric,
    expected_calibration_error,

    # Section 5: Plotting utilities
    _apply_plot_metadata,
    _compute_recalibration,
    _binned_logits,

    # Section 7: Clinical plotting
    _plot_roc_curve,
    _plot_pr_curve,
    _plot_calibration_curve,
    _plot_risk_distribution,
)


@pytest.fixture
def synthetic_data():
    """Generate synthetic y_true and y_pred for testing."""
    np.random.seed(42)
    n = 200
    y_true = np.random.binomial(1, 0.2, n)  # 20% prevalence
    y_pred = np.clip(
        0.2 * y_true + np.random.normal(0, 0.15, n),
        0.01, 0.99
    )
    return y_true, y_pred


@pytest.fixture
def temp_plot_dir():
    """Create temporary directory for plot outputs."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


# ============================================================================
# SECTION 1: FILE UTILITIES (Existing - Quick Verify)
# ============================================================================

class TestFileUtilities:
    """Test file/directory utilities."""

    def test_mkdir_creates_directory(self):
        """_mkdir should create directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_dir = os.path.join(tmpdir, "test_subdir")
            result = _mkdir(test_dir)
            assert os.path.exists(test_dir)
            assert result == test_dir

    def test_mkdir_idempotent(self):
        """_mkdir should be idempotent."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_dir = os.path.join(tmpdir, "test_subdir")
            result1 = _mkdir(test_dir)
            result2 = _mkdir(test_dir)
            assert result1 == result2 == test_dir
            assert os.path.exists(test_dir)


# ============================================================================
# SECTION 2: METRICS (Expanded from Phase 1)
# ============================================================================

class TestMetricShorthands:
    """Test metric shorthand functions (auroc, prauc, brier, logloss)."""

    def test_auroc(self, synthetic_data):
        """auroc should compute AUROC correctly."""
        y_true, y_pred = synthetic_data
        score = auroc(y_true, y_pred)
        assert 0 <= score <= 1
        assert np.isfinite(score)

    def test_prauc(self, synthetic_data):
        """prauc should compute PR-AUC correctly."""
        y_true, y_pred = synthetic_data
        score = prauc(y_true, y_pred)
        assert 0 <= score <= 1
        assert np.isfinite(score)

    def test_brier(self, synthetic_data):
        """brier should compute Brier score correctly."""
        y_true, y_pred = synthetic_data
        score = brier(y_true, y_pred)
        assert 0 <= score <= 1
        assert np.isfinite(score)

    def test_logloss(self, synthetic_data):
        """logloss should compute log loss with numerical stability."""
        y_true, y_pred = synthetic_data
        score = logloss(y_true, y_pred)
        assert score >= 0
        assert np.isfinite(score)

    def test_logloss_extreme_probabilities(self):
        """logloss should handle extreme probabilities (0 or 1)."""
        y_true = np.array([0, 1, 0, 1])
        y_pred = np.array([0.0, 1.0, 0.0, 1.0])
        score = logloss(y_true, y_pred)
        # Should not raise or return inf
        assert np.isfinite(score)


class TestFormatCI:
    """Test CI formatting function."""

    def test_format_ci_basic(self):
        """format_ci should format confidence interval correctly."""
        result = format_ci(0.123456, 0.789012, decimals=3)
        assert result == "[0.123, 0.789]"

    def test_format_ci_custom_decimals(self):
        """format_ci should respect decimals parameter."""
        result = format_ci(0.1234567, 0.8901234, decimals=4)
        assert result == "[0.1235, 0.8901]"

    def test_format_ci_invalid_values(self):
        """format_ci should return empty string for invalid bounds."""
        result = format_ci(np.nan, 0.5)
        assert result == ""

        result = format_ci(0.5, np.inf)
        assert result == ""


class TestComputeMetricsWithCIs:
    """Test batch metrics with CI computation."""

    def test_compute_metrics_basic(self, synthetic_data):
        """compute_metrics_with_cis should return dict with metrics."""
        y_true, y_pred = synthetic_data
        result = compute_metrics_with_cis(
            y_true, y_pred,
            n_boot=0,
            suffix="_test",
            include_cis=False
        )
        assert "AUROC_test" in result
        assert "PR_AUC_test" in result
        assert "Brier_test" in result
        assert all(isinstance(v, (float, int)) for v in result.values())

    def test_compute_metrics_with_cis(self, synthetic_data):
        """compute_metrics_with_cis should include CI strings when requested."""
        y_true, y_pred = synthetic_data
        result = compute_metrics_with_cis(
            y_true, y_pred,
            n_boot=50,
            seed=42,
            suffix="_val",
            include_cis=True
        )
        assert "AUROC_val" in result
        assert "AUROC_val_95CI" in result
        assert isinstance(result["AUROC_val_95CI"], str)
        # Check CI format
        assert result["AUROC_val_95CI"].startswith("[")
        assert result["AUROC_val_95CI"].endswith("]")

    def test_compute_metrics_suffix(self, synthetic_data):
        """compute_metrics_with_cis should apply suffix correctly."""
        y_true, y_pred = synthetic_data
        result = compute_metrics_with_cis(
            y_true, y_pred,
            suffix="_custom",
            include_cis=False
        )
        assert all(k.endswith("_custom") for k in result.keys())


class TestBootstrapCI:
    """Test bootstrap confidence interval computation."""

    def test_stratified_bootstrap_ci(self, synthetic_data):
        """stratified_bootstrap_ci should return valid bounds."""
        y_true, y_pred = synthetic_data
        from sklearn.metrics import roc_auc_score

        ci_lo, ci_hi = stratified_bootstrap_ci(
            y_true, y_pred,
            metric_fn=roc_auc_score,
            n_boot=50,
            seed=42
        )
        assert np.isfinite(ci_lo) and np.isfinite(ci_hi)
        assert ci_lo <= ci_hi
        assert 0 <= ci_lo <= 1
        assert 0 <= ci_hi <= 1

    def test_stratified_bootstrap_reproducibility(self, synthetic_data):
        """stratified_bootstrap_ci should be reproducible with same seed."""
        y_true, y_pred = synthetic_data
        from sklearn.metrics import roc_auc_score

        ci1 = stratified_bootstrap_ci(
            y_true, y_pred,
            metric_fn=roc_auc_score,
            n_boot=50,
            seed=42
        )
        ci2 = stratified_bootstrap_ci(
            y_true, y_pred,
            metric_fn=roc_auc_score,
            n_boot=50,
            seed=42
        )
        assert np.allclose(ci1, ci2)


# ============================================================================
# SECTION 3: THRESHOLD SELECTION (Phase 2)
# ============================================================================

class TestThresholdSelection:
    """Test threshold selection functions."""

    def test_threshold_max_f1(self, synthetic_data):
        """threshold_max_f1 should select optimal F1 threshold."""
        y_true, y_pred = synthetic_data
        threshold = threshold_max_f1(y_true, y_pred)
        assert 0 <= threshold <= 1
        assert np.isfinite(threshold)

    def test_threshold_max_fbeta(self, synthetic_data):
        """threshold_max_fbeta should select optimal F-beta threshold."""
        y_true, y_pred = synthetic_data
        threshold = threshold_max_fbeta(y_true, y_pred, beta=2)
        assert 0 <= threshold <= 1
        assert np.isfinite(threshold)

    def test_threshold_youden(self, synthetic_data):
        """threshold_youden should select Youden's J threshold."""
        y_true, y_pred = synthetic_data
        threshold = threshold_youden(y_true, y_pred)
        assert 0 <= threshold <= 1
        assert np.isfinite(threshold)

    def test_threshold_for_specificity(self, synthetic_data):
        """threshold_for_specificity should select for target specificity."""
        y_true, y_pred = synthetic_data
        target_spec = 0.95
        threshold = threshold_for_specificity(y_true, y_pred, target_spec)
        assert 0 <= threshold <= 1
        assert np.isfinite(threshold)

        # Verify achieved specificity is close to target
        y_pred_binary = (y_pred >= threshold).astype(int)
        tn = ((y_true == 0) & (y_pred_binary == 0)).sum()
        fp = ((y_true == 0) & (y_pred_binary == 1)).sum()
        spec = tn / (tn + fp) if (tn + fp) > 0 else 0
        # Allow some tolerance due to threshold discretization
        assert spec >= target_spec - 0.05

    def test_threshold_for_precision(self, synthetic_data):
        """threshold_for_precision should select for target precision."""
        y_true, y_pred = synthetic_data
        target_prec = 0.8
        threshold = threshold_for_precision(y_true, y_pred, target_prec)
        assert 0 <= threshold <= 1
        assert np.isfinite(threshold)

    def test_binary_metrics_at_threshold(self, synthetic_data):
        """binary_metrics_at_threshold should compute threshold-specific metrics."""
        y_true, y_pred = synthetic_data
        threshold = 0.5
        metrics = binary_metrics_at_threshold(y_true, y_pred, threshold)

        assert "recall" in metrics
        assert "specificity" in metrics
        assert "precision" in metrics
        assert "threshold" in metrics
        assert all(isinstance(v, (float, int)) for v in [metrics["recall"], metrics["specificity"], metrics["precision"]])

    def test_top_risk_capture(self, synthetic_data):
        """top_risk_capture should compute capture at various fractions."""
        y_true, y_pred = synthetic_data
        result = top_risk_capture(y_true, y_pred, frac=0.2)
        assert "case_capture" in result
        assert 0 <= result["case_capture"] <= 1
        assert np.isfinite(result["case_capture"])

    def test_choose_threshold_objective(self, synthetic_data):
        """choose_threshold_objective should select threshold by objective."""
        y_true, y_pred = synthetic_data

        # Test 'max_f1'
        name, threshold = choose_threshold_objective(y_true, y_pred, 'max_f1')
        assert name == 'max_f1'
        assert 0 <= threshold <= 1

        # Test 'youden'
        name, threshold = choose_threshold_objective(y_true, y_pred, 'youden')
        assert name == 'youden'
        assert 0 <= threshold <= 1


# ============================================================================
# SECTION 4: CALIBRATION (Phase 2)
# ============================================================================

class TestPrevalenceAdjustment:
    """Test probability prevalence adjustment."""

    def test_adjust_probabilities_basic(self):
        """adjust_probabilities_for_prevalence should scale probabilities."""
        p = np.array([0.05, 0.10, 0.20, 0.50, 0.90])
        p_adj = adjust_probabilities_for_prevalence(
            p,
            sample_prev=0.2,
            target_prev=0.05
        )
        assert p_adj.shape == p.shape
        assert np.all((0 <= p_adj) & (p_adj <= 1))

    def test_adjust_probabilities_preserves_order(self):
        """adjust_probabilities_for_prevalence should preserve rank order."""
        p = np.array([0.05, 0.10, 0.20, 0.50, 0.90])
        p_adj = adjust_probabilities_for_prevalence(
            p,
            sample_prev=0.2,
            target_prev=0.05
        )
        # Ordering should be preserved
        assert all(p_adj[:-1] <= p_adj[1:])

    def test_adjust_probabilities_extreme_cases(self):
        """adjust_probabilities_for_prevalence should handle edge cases."""
        p = np.array([0.01, 0.5, 0.99])

        # Same prevalence should return similar values
        p_adj = adjust_probabilities_for_prevalence(p, 0.2, 0.2)
        assert np.allclose(p, p_adj, atol=1e-6)


class TestCalibrationMetrics:
    """Test calibration metrics (intercept, slope, ECE)."""

    def test_calibration_intercept_slope(self, synthetic_data):
        """calibration_intercept_slope should compute valid metrics."""
        y_true, y_pred = synthetic_data
        intercept, slope = calibration_intercept_slope(y_true, y_pred)
        assert np.isfinite(intercept)
        assert np.isfinite(slope)

    def test_calib_intercept_metric(self, synthetic_data):
        """calib_intercept_metric should compute intercept."""
        y_true, y_pred = synthetic_data
        intercept = calib_intercept_metric(y_true, y_pred)
        assert np.isfinite(intercept)

    def test_calib_slope_metric(self, synthetic_data):
        """calib_slope_metric should compute slope."""
        y_true, y_pred = synthetic_data
        slope = calib_slope_metric(y_true, y_pred)
        assert np.isfinite(slope)

    def test_expected_calibration_error(self, synthetic_data):
        """expected_calibration_error should compute ECE."""
        y_true, y_pred = synthetic_data
        ece = expected_calibration_error(y_true, y_pred, n_bins=10)
        assert 0 <= ece <= 1
        assert np.isfinite(ece)


class TestPrevalenceAdjustedModel:
    """Test PrevalenceAdjustedModel wrapper class."""

    def test_prevalence_adjusted_model_initialization(self):
        """PrevalenceAdjustedModel should initialize correctly."""
        from sklearn.linear_model import LogisticRegression
        model = PrevalenceAdjustedModel(
            base_model=LogisticRegression(),
            sample_prevalence=0.2,
            target_prevalence=0.05
        )
        assert model.sample_prevalence == 0.2
        assert model.target_prevalence == 0.05

    def test_prevalence_adjusted_model_fit_predict(self, synthetic_data):
        """PrevalenceAdjustedModel should fit and predict with adjustment."""
        from sklearn.linear_model import LogisticRegression

        y_true, y_pred = synthetic_data
        X = np.random.randn(len(y_true), 5)

        # Fit base model first
        base_model = LogisticRegression(max_iter=1000)
        base_model.fit(X, y_true)

        # Wrap with prevalence adjustment
        model = PrevalenceAdjustedModel(
            base_model=base_model,
            sample_prevalence=y_true.mean(),
            target_prevalence=0.05
        )
        y_pred_adjusted = model.predict_proba(X)[:, 1]

        assert y_pred_adjusted.shape == y_true.shape
        assert np.all((0 <= y_pred_adjusted) & (y_pred_adjusted <= 1))


# ============================================================================
# SECTION 5: PLOTTING UTILITIES
# ============================================================================

class TestPlottingUtilities:
    """Test plotting helper functions."""

    def test_compute_recalibration(self, synthetic_data):
        """_compute_recalibration should compute calibration metrics."""
        y_true, y_pred = synthetic_data
        intercept, slope = _compute_recalibration(y_true, y_pred)
        assert np.isfinite(intercept)
        assert np.isfinite(slope)

    def test_binned_logits(self, synthetic_data):
        """_binned_logits should compute binned statistics."""
        y_true, y_pred = synthetic_data
        xs, ys, ys_lo, ys_hi, sizes = _binned_logits(
            y_true, y_pred,
            n_bins=5,
            bin_strategy="quantile",
            min_bin_size=5
        )
        assert xs is not None
        assert len(xs) == len(ys) == len(ys_lo) == len(ys_hi) == len(sizes)
        assert all(s > 0 for s in sizes)


# ============================================================================
# SECTION 7: CLINICAL PLOTTING (Phase 3)
# ============================================================================

class TestClinicalPlotting:
    """Test clinical plotting functions."""

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_roc_curve_basic(self, synthetic_data, temp_plot_dir):
        """_plot_roc_curve should generate valid plot file."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "roc.png")

        _plot_roc_curve(
            y_true, y_pred,
            out_path=out_path,
            title="Test ROC"
        )
        assert os.path.exists(out_path)
        assert os.path.getsize(out_path) > 0

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_roc_curve_with_metadata(self, synthetic_data, temp_plot_dir):
        """_plot_roc_curve should include metadata lines."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "roc_meta.png")

        _plot_roc_curve(
            y_true, y_pred,
            out_path=out_path,
            title="Test ROC",
            meta_lines=["Train: n=100", "Test: n=50"]
        )
        assert os.path.exists(out_path)

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_pr_curve_basic(self, synthetic_data, temp_plot_dir):
        """_plot_pr_curve should generate valid plot file."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "pr.png")

        _plot_pr_curve(
            y_true, y_pred,
            out_path=out_path,
            title="Test PR"
        )
        assert os.path.exists(out_path)
        assert os.path.getsize(out_path) > 0

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_calibration_curve_basic(self, synthetic_data, temp_plot_dir):
        """_plot_calibration_curve should generate valid plot file."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "calib.png")

        _plot_calibration_curve(
            y_true, y_pred,
            out_path=out_path,
            title="Test Calibration",
            n_bins=5
        )
        assert os.path.exists(out_path)
        assert os.path.getsize(out_path) > 0

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_calibration_curve_5panel(self, synthetic_data, temp_plot_dir):
        """_plot_calibration_curve should support 5-panel layout."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "calib_5panel.png")

        _plot_calibration_curve(
            y_true, y_pred,
            out_path=out_path,
            title="Test Calibration 5-Panel",
            n_bins=5,
            four_panel=True
        )
        assert os.path.exists(out_path)

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_risk_distribution_basic(self, synthetic_data, temp_plot_dir):
        """_plot_risk_distribution should generate valid plot file."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "risk_dist.png")

        _plot_risk_distribution(
            y_true, y_pred,
            out_path=out_path,
            title="Test Risk Distribution"
        )
        assert os.path.exists(out_path)
        assert os.path.getsize(out_path) > 0

    @pytest.mark.skip(reason="Requires matplotlib, skipped in test environment")
    def test_plot_risk_distribution_with_threshold(self, synthetic_data, temp_plot_dir):
        """_plot_risk_distribution should support threshold overlays."""
        y_true, y_pred = synthetic_data
        out_path = os.path.join(temp_plot_dir, "risk_dist_threshold.png")

        _plot_risk_distribution(
            y_true, y_pred,
            out_path=out_path,
            title="Test Risk Distribution",
            dca_threshold=0.5,
            spec95_threshold=0.3
        )
        assert os.path.exists(out_path)


# ============================================================================
# EDGE CASES & CORNER CASES
# ============================================================================

class TestEdgeCases:
    """Test edge cases and corner cases."""

    def test_perfect_separation(self):
        """Test metrics with perfectly separable data."""
        y_true = np.array([0, 0, 0, 1, 1, 1])
        y_pred = np.array([0.0, 0.0, 0.0, 1.0, 1.0, 1.0])

        auroc_score = auroc(y_true, y_pred)
        assert auroc_score == 1.0

    def test_random_predictions(self):
        """Test metrics with random predictions."""
        np.random.seed(42)
        y_true = np.random.binomial(1, 0.5, 100)
        y_pred = np.random.uniform(0, 1, 100)

        auroc_score = auroc(y_true, y_pred)
        # Random predictions should have AUROC near 0.5
        assert 0.3 < auroc_score < 0.7

    def test_single_class(self):
        """Test metrics when only one class is present."""
        y_true = np.array([0, 0, 0, 0])
        y_pred = np.array([0.1, 0.2, 0.3, 0.4])

        # Should handle gracefully
        metrics = prob_metrics(y_true, y_pred, include_logloss=False)
        assert "Brier" in metrics

    def test_small_sample_size(self):
        """Test with very small sample sizes."""
        y_true = np.array([0, 1])
        y_pred = np.array([0.3, 0.7])

        metrics = prob_metrics(y_true, y_pred, include_logloss=False)
        assert "AUROC" in metrics
        assert np.isfinite(metrics["AUROC"])

    def test_identical_probabilities(self):
        """Test when all probabilities are identical."""
        y_true = np.array([0, 0, 1, 1])
        y_pred = np.array([0.5, 0.5, 0.5, 0.5])

        threshold = threshold_max_f1(y_true, y_pred)
        assert 0 <= threshold <= 1


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestIntegration:
    """Integration tests combining multiple functions."""

    def test_workflow_metrics_to_thresholds(self, synthetic_data, temp_plot_dir):
        """Test typical workflow: compute metrics → select threshold → evaluate."""
        y_true, y_pred = synthetic_data

        # Step 1: Compute metrics (default suffix is empty)
        metrics = compute_metrics_with_cis(y_true, y_pred, n_boot=20, include_cis=True)
        assert "AUROC" in metrics

        # Step 2: Select threshold
        threshold = threshold_youden(y_true, y_pred)

        # Step 3: Evaluate at threshold
        threshold_metrics = binary_metrics_at_threshold(y_true, y_pred, threshold)
        assert "recall" in threshold_metrics

    def test_workflow_prevalence_adjustment(self):
        """Test calibration workflow with prevalence adjustment."""
        from sklearn.linear_model import LogisticRegression

        np.random.seed(42)
        X = np.random.randn(100, 5)
        y = np.random.binomial(1, 0.2, 100)

        # Fit base model
        base_model = LogisticRegression(max_iter=1000)
        base_model.fit(X, y)

        # Wrap with prevalence adjustment
        model = PrevalenceAdjustedModel(
            base_model=base_model,
            sample_prevalence=0.2,
            target_prevalence=0.05
        )

        # Predict and validate
        y_pred = model.predict_proba(X)[:, 1]
        assert np.all((0 <= y_pred) & (y_pred <= 1))

    def test_workflow_complete_pipeline(self, synthetic_data, temp_plot_dir):
        """Test complete pipeline: metrics → calibration (no plotting due to matplotlib)."""
        y_true, y_pred = synthetic_data

        # Compute metrics
        metrics = prob_metrics(y_true, y_pred)
        auroc_val = metrics["AUROC"]

        # Compute calibration
        intercept, slope = calibration_intercept_slope(y_true, y_pred)

        # Verify outputs (plotting skipped - matplotlib not available)
        assert np.isfinite(auroc_val)
        assert np.isfinite(intercept) and np.isfinite(slope)
        assert "AUROC" in metrics
        assert "Brier" in metrics


# ============================================================================
# MAIN TEST RUNNER
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
