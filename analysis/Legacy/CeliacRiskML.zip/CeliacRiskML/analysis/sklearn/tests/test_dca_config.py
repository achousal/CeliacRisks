#!/usr/bin/env python3
"""
Test DCA curve generation with extended range (0.05% to 100%).
"""

import numpy as np
import sys

# Import DCA function
try:
    from celiacML_faith import decision_curve_analysis, _dca_thresholds
    print("✓ Imported DCA functions from celiacML_faith")
except ImportError as e:
    print(f"✗ Failed to import: {e}")
    sys.exit(1)

print("\n" + "="*70)
print("Testing DCA Curve Generation with Extended Range")
print("="*70)

# Generate mock data (low prevalence like Celiac)
np.random.seed(42)
n_controls = 1000
n_cases = 50
prevalence = n_cases / (n_controls + n_cases)

# Controls have low risk, cases have higher risk
scores_controls = np.random.beta(2, 8, n_controls)
scores_cases = np.random.beta(5, 3, n_cases)

scores = np.concatenate([scores_controls, scores_cases])
y_true = np.array([0]*n_controls + [1]*n_cases)

print(f"\nMock Data:")
print(f"  Controls: {n_controls} (mean risk: {scores_controls.mean():.3f})")
print(f"  Cases: {n_cases} (mean risk: {scores_cases.mean():.3f})")
print(f"  Prevalence: {prevalence:.2%}")

# Test 1: Extended DCA range (0.05% to 100%)
print(f"\n{'='*70}")
print("Test 1: Extended DCA Range (0.0005 to 1.0 with step 0.001)")
print(f"{'='*70}")

thresholds_extended = _dca_thresholds(0.0005, 1.0, 0.001)
print(f"✓ Generated {len(thresholds_extended)} thresholds")
print(f"  Range: {thresholds_extended[0]:.4f} to {thresholds_extended[-1]:.4f}")
print(f"  First 5: {thresholds_extended[:5]}")
print(f"  Last 5: {thresholds_extended[-5:]}")

dca_extended = decision_curve_analysis(y_true, scores, thresholds=thresholds_extended)
print(f"✓ Computed DCA with {len(dca_extended)} rows")

# Find zero crossing
net_benefits = dca_extended['net_benefit_model'].values
for i in range(len(net_benefits) - 1):
    if net_benefits[i] < 0 and net_benefits[i+1] >= 0:
        threshold_zero = thresholds_extended[i]
        print(f"✓ DCA zero crossing found at threshold: {threshold_zero:.4f} ({threshold_zero*100:.2f}%)")
        break
else:
    print(f"✗ DCA zero crossing not found in range")

# Test 2: Original narrow range (for comparison)
print(f"\n{'='*70}")
print("Test 2: Original Narrow Range (0.001 to 0.10 with step 0.001)")
print(f"{'='*70}")

thresholds_narrow = _dca_thresholds(0.001, 0.10, 0.001)
print(f"✓ Generated {len(thresholds_narrow)} thresholds")
print(f"  Range: {thresholds_narrow[0]:.4f} to {thresholds_narrow[-1]:.4f}")

dca_narrow = decision_curve_analysis(y_true, scores, thresholds=thresholds_narrow)
print(f"✓ Computed DCA with {len(dca_narrow)} rows")

# Check zero crossing in narrow range
net_benefits_narrow = dca_narrow['net_benefit_model'].values
zero_in_narrow = any(net_benefits_narrow[i] < 0 and net_benefits_narrow[i+1] >= 0
                      for i in range(len(net_benefits_narrow)-1))
if zero_in_narrow:
    print(f"✓ DCA zero crossing IS in narrow range")
else:
    print(f"✗ DCA zero crossing NOT in narrow range (would miss it!)")

print(f"\n{'='*70}")
print("Summary")
print(f"{'='*70}")
print(f"Extended range captures: {len(thresholds_extended)} points vs {len(thresholds_narrow)} points")
print(f"Coverage improvement: {len(thresholds_extended)/len(thresholds_narrow):.1f}x more granular")
print(f"\nRecommended configuration:")
print(f"  DCA_THRESHOLD_MIN: 0.0005  (0.05%)")
print(f"  DCA_THRESHOLD_MAX: 1.0     (100%)")
print(f"  DCA_THRESHOLD_STEP: 0.001  (0.1%)")
print(f"\n✓ All DCA configuration tests passed!")
