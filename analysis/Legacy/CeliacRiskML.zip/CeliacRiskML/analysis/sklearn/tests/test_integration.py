#!/usr/bin/env python3
"""
Integration test to verify enhanced plots work with all splits (TRAIN/VAL/TEST).
"""

import numpy as np
import os
import sys

# Test import of enhanced functions
try:
    from postprocess_compare import (
        find_dca_zero_crossing,
        load_spec95_threshold,
        compute_distribution_stats,
        _plot_risk_distribution
    )
    print("✓ Successfully imported enhanced plotting functions from postprocess_compare")
except ImportError as e:
    print(f"✗ Failed to import: {e}")
    sys.exit(1)

# Test import from celiacML_faith
try:
    import celiacML_faith
    if hasattr(celiacML_faith, 'ENHANCED_PLOTS_AVAILABLE'):
        print(f"✓ celiacML_faith.ENHANCED_PLOTS_AVAILABLE = {celiacML_faith.ENHANCED_PLOTS_AVAILABLE}")
    else:
        print("✗ ENHANCED_PLOTS_AVAILABLE not found in celiacML_faith")
except Exception as e:
    print(f"✗ Error checking celiacML_faith: {e}")

print("\nAll integration checks passed!")
print("\nNext steps:")
print("1. Run your ML pipeline on HPC: bsub < CeD_optimized.lsf")
print("2. Check output logs for any '[WARNING] Enhanced plot failed' messages")
print("3. Verify plots exist with enhanced features:")
print("   - TEST_risk_distribution.png (2 panels: main + incident)")
print("   - VAL_risk_distribution.png (2 panels: main + incident)")
print("   - TRAIN_OOF_risk_distribution.png (3 panels: main + incident + prevalent)")
