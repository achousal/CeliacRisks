#!/usr/bin/env python3
"""
test_enhanced_plots.py

Quick test script to verify enhanced risk distribution plotting functions.
Tests the new helper functions and plotting enhancements.
"""

import numpy as np
import os
import tempfile

# Import the enhanced functions
from postprocess_compare import (
    find_dca_zero_crossing,
    load_spec95_threshold,
    compute_distribution_stats,
    _plot_risk_distribution,
)

def test_compute_distribution_stats():
    """Test distribution statistics computation."""
    print("Testing compute_distribution_stats...")

    # Test with normal data
    scores = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
    stats = compute_distribution_stats(scores)

    assert abs(stats['mean'] - 0.5) < 0.01
    assert abs(stats['median'] - 0.5) < 0.01
    assert stats['q1'] == 0.3
    assert stats['q3'] == 0.7
    assert abs(stats['iqr'] - 0.4) < 0.01

    print("  ✓ Basic statistics calculation passed")

    # Test with empty array
    empty_stats = compute_distribution_stats(np.array([]))
    assert np.isnan(empty_stats['mean'])

    print("  ✓ Empty array handling passed")

    # Test with NaN values
    scores_with_nan = np.array([0.1, np.nan, 0.3, 0.5, np.nan])
    stats_nan = compute_distribution_stats(scores_with_nan)
    assert np.isfinite(stats_nan['mean'])

    print("  ✓ NaN filtering passed")
    print()


def test_plot_risk_distribution():
    """Test enhanced risk distribution plotting."""
    print("Testing _plot_risk_distribution...")

    # Generate mock data
    np.random.seed(42)
    n_controls = 100
    n_incident = 40  # Increased for better KDE
    n_prevalent = 30  # Increased for better KDE

    # Create risk scores (incident/prevalent have higher risk)
    scores_controls = np.random.beta(2, 8, n_controls)  # Lower risk
    scores_incident = np.random.beta(5, 3, n_incident)  # Higher risk
    scores_prevalent = np.random.beta(6, 2, n_prevalent)  # Even higher risk

    scores = np.concatenate([scores_controls, scores_incident, scores_prevalent])
    y_true = np.array([0]*n_controls + [1]*n_incident + [1]*n_prevalent)
    category_col = np.array(['Controls']*n_controls + ['Incident']*n_incident + ['Prevalent']*n_prevalent)

    # Mock thresholds
    dca_threshold = 0.15
    spec95_threshold = 0.45

    # Mock metrics
    metrics_at_thresholds = {
        'dca': {
            'sensitivity': 0.85,
            'precision': 0.12,
            'fp': 15,
            'n_celiac': n_incident + n_prevalent,
        },
        'spec95': {
            'sensitivity': 0.60,
            'precision': 0.35,
            'fp': 5,
            'n_celiac': n_incident + n_prevalent,
        }
    }

    # Create temporary output file
    with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
        out_path = tmp.name

    try:
        # Test basic plot (no enhancements)
        _plot_risk_distribution(
            y_true=y_true,
            scores=scores,
            out_path=out_path,
            title="Test Risk Distribution (Basic)",
        )
        assert os.path.exists(out_path)
        print("  ✓ Basic plot generation passed")

        # Test enhanced plot with category_col
        _plot_risk_distribution(
            y_true=y_true,
            scores=scores,
            out_path=out_path,
            title="Test Risk Distribution (With Categories)",
            category_col=category_col,
        )
        assert os.path.exists(out_path)
        print("  ✓ Category column plot passed")

        # Test full enhanced plot with thresholds
        _plot_risk_distribution(
            y_true=y_true,
            scores=scores,
            out_path=out_path,
            title="Test Risk Distribution (Full Enhancement)",
            category_col=category_col,
            dca_threshold=dca_threshold,
            spec95_threshold=spec95_threshold,
            metrics_at_thresholds=metrics_at_thresholds,
        )
        assert os.path.exists(out_path)
        print("  ✓ Full enhanced plot with thresholds passed")

        # Test incident-only plot (like VAL/TEST splits without prevalent)
        category_col_incident_only = np.array(['Controls']*n_controls + ['Incident']*n_incident)
        scores_incident_only = np.concatenate([scores_controls, scores_incident])
        y_true_incident_only = np.array([0]*n_controls + [1]*n_incident)

        _plot_risk_distribution(
            y_true=y_true_incident_only,
            scores=scores_incident_only,
            out_path=out_path,
            title="Test Risk Distribution (Incident Only - VAL/TEST)",
            category_col=category_col_incident_only,
            dca_threshold=dca_threshold,
            spec95_threshold=spec95_threshold,
            metrics_at_thresholds=metrics_at_thresholds,
        )
        assert os.path.exists(out_path)
        print("  ✓ Incident-only plot (VAL/TEST scenario) passed")

        print(f"  ✓ Test plot saved to: {out_path}")

    finally:
        # Clean up
        if os.path.exists(out_path):
            os.unlink(out_path)
            print("  ✓ Cleaned up test file")

    print()


def test_find_dca_zero_crossing():
    """Test DCA zero-crossing threshold extraction."""
    print("Testing find_dca_zero_crossing...")

    # Create mock DCA curve file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
        tmp.write("threshold,net_benefit_model,net_benefit_all,net_benefit_none\n")
        tmp.write("0.001,-0.05,0.01,0.0\n")
        tmp.write("0.005,-0.02,0.005,0.0\n")
        tmp.write("0.010,0.01,0.002,0.0\n")  # Crosses here (between 0.005 and 0.010)
        tmp.write("0.020,0.03,-0.001,0.0\n")
        tmp.write("0.050,0.02,-0.01,0.0\n")
        dca_path = tmp.name

    try:
        crossing = find_dca_zero_crossing(dca_path)
        assert crossing is not None
        assert 0.005 < crossing < 0.010  # Should be interpolated between these
        print(f"  ✓ DCA crossing found at {crossing:.4f} (expected between 0.005 and 0.010)")

        # Test with non-existent file
        crossing_none = find_dca_zero_crossing("/nonexistent/path.csv")
        assert crossing_none is None
        print("  ✓ Non-existent file handling passed")

    finally:
        os.unlink(dca_path)
        print("  ✓ Cleaned up test file")

    print()


def test_load_spec95_threshold():
    """Test spec95 threshold loading from metrics CSV."""
    print("Testing load_spec95_threshold...")

    # Create mock test_metrics.csv
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
        tmp.write("scenario,model,thr_train_oof_spec95_ctrl,sensitivity_test_at_spec95_ctrl\n")
        tmp.write("IncidentPlusPrevalent,RF,0.456,0.62\n")
        metrics_path = tmp.name

    try:
        threshold = load_spec95_threshold(metrics_path, split='test')
        assert threshold is not None
        assert abs(threshold - 0.456) < 0.001
        print(f"  ✓ Spec95 threshold loaded: {threshold:.3f}")

        # Test with non-existent file
        threshold_none = load_spec95_threshold("/nonexistent/metrics.csv")
        assert threshold_none is None
        print("  ✓ Non-existent file handling passed")

    finally:
        os.unlink(metrics_path)
        print("  ✓ Cleaned up test file")

    print()


def main():
    """Run all tests."""
    print("="*60)
    print("Enhanced Risk Distribution Plotting Tests")
    print("="*60)
    print()

    try:
        test_compute_distribution_stats()
        test_find_dca_zero_crossing()
        test_load_spec95_threshold()
        test_plot_risk_distribution()

        print("="*60)
        print("All tests passed! ✓")
        print("="*60)
        return 0

    except AssertionError as e:
        print(f"\n✗ Test failed: {e}")
        return 1
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    import sys
    sys.exit(main())
