#!/usr/bin/env python3
"""
Simple integration test for DCA migration.
Tests that all imports work and basic DCA computation functions.
"""

import numpy as np
import sys

print("Testing DCA migration...")

# Test 1: Import DCA from shared_utils
print("\n[1/5] Testing DCA imports from shared_utils...")
from shared_utils import (
    _dca_thresholds,
    _parse_dca_report_points,
    decision_curve_analysis,
    compute_dca_summary,
    save_dca_results
)
print("✓ All DCA functions imported successfully from shared_utils")

# Test 2: Import celiacML_faith with DCA functions
print("\n[2/5] Testing celiacML_faith imports...")
# Just check that the file can be imported without errors
import celiacML_faith
print("✓ celiacML_faith imports DCA functions successfully")

# Test 3: Import postprocess_compare with DCA functions
print("\n[3/5] Testing postprocess_compare imports...")
import postprocess_compare
print("✓ postprocess_compare imports DCA functions successfully")

# Test 4: Test DCA computation with synthetic data
print("\n[4/5] Testing DCA computation...")
np.random.seed(42)
n = 100
y_true = np.array([0] * 80 + [1] * 20)
y_pred = np.random.rand(n)
y_pred[80:] += 0.3  # Make positives have higher scores

thresholds = _dca_thresholds(0.01, 0.5, 0.05)
dca_df = decision_curve_analysis(y_true, y_pred, thresholds=thresholds)

assert len(dca_df) > 0, "DCA DataFrame should not be empty"
assert "threshold" in dca_df.columns, "DCA DataFrame should have threshold column"
assert "net_benefit_model" in dca_df.columns, "DCA DataFrame should have net_benefit_model column"
print(f"✓ DCA computed successfully ({len(dca_df)} threshold points)")

# Test 5: Test DCA summary
print("\n[5/5] Testing DCA summary...")
summary = compute_dca_summary(dca_df, report_points=[0.05, 0.10])
assert summary.get("dca_computed") == True, "DCA should be marked as computed"
assert "threshold_range" in summary, "Summary should include threshold range"
print(f"✓ DCA summary computed: {summary.get('threshold_range', 'N/A')}")

print("\n" + "="*60)
print("✓ All tests passed! DCA migration is working correctly.")
print("="*60)
